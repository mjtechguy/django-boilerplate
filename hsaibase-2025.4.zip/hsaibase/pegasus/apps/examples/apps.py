from django.apps import AppConfig


class PegasusExamplesConfig(AppConfig):
    name = "pegasus.apps.examples"
    label = "pegasus_examples"
