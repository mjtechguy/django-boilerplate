import htmx from "htmx.org"
window.htmx = htmx
