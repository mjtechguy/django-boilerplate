// put site-wide dependencies here.
// HTMX setup: https://htmx.org/docs/#installing
import './htmx';
import './alpine';
