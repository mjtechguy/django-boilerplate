
// if your API lives at a different namespace you can add it here
// e.g. API_ROOT = ["myapp", "api"];
export const API_ROOT = ["pegasus", "employees", "api"];
