Copyright © 2024, Elodin Labs LLC (SaaS Pegasus).

This software is licensed under License ID: fc2a2a0f-2c2b-4f14-8069-39bf71acf35f

Permission is hereby granted to any person purchasing a copy of SaaS Pegasus,
its source code and associated documentation files (the “Software”), to install,
use, and modify this version of the Software for the purpose of building a single
production application. This does not include the rights to publish, distribute,
sublicense, and/or sell copies of the Software or source code without prior
consent from Elodin Labs LLC.

In the event of a transfer of the code, the license and all associated applications
are also transferred. You may re-license this code at any time with a different, valid,
compatible SaaS Pegasus license, under the terms outlined on our website at
https://www.saaspegasus.com/license/.

The above copyright notice and this permission notice shall be included in all
copies or substantial portions of the Software.

THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
SOFTWARE.

The user of the software represents and warrants that they will at all times comply
with applicable law in their download and use of the Software.
