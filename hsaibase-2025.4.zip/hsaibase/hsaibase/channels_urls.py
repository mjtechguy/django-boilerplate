from apps.group_chat.routing import websocket_urlpatterns as group_chat_patterns

urlpatterns = [] + group_chat_patterns
